# Sentinel 3 — monitoramento residencial com câmeras e assistente de IA

Site comercial + painel de monitoramento. A webcam do computador e qualquer
celular viram câmeras, com reconhecimento facial, detecção de movimento,
gravação e um assistente que entende português e age no painel.

```
sentinel/
├── frontend/          HTML/CSS/JS puro
│   ├── index.html     site de vendas (planos, recursos, contato)
│   ├── login.html     entrar
│   ├── cadastro.html  criar conta
│   ├── painel.html    central de monitoramento
│   └── celular.html   página que transforma o celular em câmera
├── backend/           Node.js + Express + TypeScript + MySQL + Socket.IO
└── web/               protótipo antigo em React (não é usado)
```

## Como rodar

```bash
cd backend
cp .env.example .env      # preencha a senha do MySQL
npm install
npm run migrate           # cria o banco e o usuário de teste
npm run dev
```

Abra **http://localhost:3001** — o próprio back-end serve o site.
Conta de teste: `operador@sentinel.com` / `Sentinel123`.

## Câmera do celular

1. No `.env`, deixe `HTTPS=true` (já vem assim no exemplo).
2. No painel, clique em **Conectar celular** e escaneie o QR Code.
3. Na primeira vez o celular avisa que o certificado não é confiável
   (ele é gerado pelo próprio servidor): toque em *Avançado → Continuar*.

Sem HTTPS o navegador do celular **bloqueia a câmera** — era por isso que a
câmera do celular não abria na versão anterior.

Se não aparecer vídeo: os dois aparelhos precisam estar no mesmo Wi-Fi, e o
Firewall do Windows precisa liberar o Node nas portas 3001 e 3443.

## Assistente com IA

Sem configurar nada, o assistente funciona em **modo local** (regras).
Para conversar com uma IA de verdade, escolha uma opção no `.env`:

| Opção | O que colocar no `.env` | Custo |
|---|---|---|
| Ollama (roda no seu PC) | `IA_PROVEDOR=openai`, `OPENAI_BASE_URL=http://localhost:11434/v1`, `OPENAI_MODEL=llama3.1` | grátis |
| Claude (Anthropic) | `ANTHROPIC_API_KEY=...` | pago por uso |
| OpenAI ou compatível | `IA_PROVEDOR=openai`, `OPENAI_API_KEY=...`, `OPENAI_MODEL=...` | pago por uso |

A IA recebe o estado do painel (sensores, risco, câmeras, último acesso) e usa
*ferramentas* para agir: trancar a porta, ligar rosto/movimento/gravação numa
câmera, tirar foto, acionar emergência, e consultar no MySQL o histórico de
eventos, acessos e acionamentos. Tudo em `backend/src/ia.ts`.

## O que tem no painel

- **Câmeras**: várias webcams ao mesmo tempo, celulares via QR Code, layout
  1 / 2×2 / 3×3, destaque, tela cheia, foto com data e hora gravadas na
  imagem, gravação em vídeo (.webm), e o painel lembra das câmeras.
- **Reconhecimento facial**: vários rostos por quadro, com nome desenhado no
  vídeo. Câmeras com "Entrada", "Porta" ou "Portão" no nome liberam a porta
  por 15 s para moradores reconhecidos.
- **Detecção de movimento**: compara quadros, marca a área e salva uma foto
  na linha do tempo de capturas.
- **Sensores, planta e índice de risco**; acima de 90% o protocolo aciona o
  serviço certo com 5 segundos para cancelar (chamadas simuladas).
- **Tempo real**: vários painéis abertos veem os mesmos eventos (Socket.IO).

## Rotas novas da API

| Método | Rota | Para quê |
|---|---|---|
| GET | `/api/assistente/status` | se há IA configurada |
| POST | `/api/assistente/chat` | conversa com a IA (exige login) |
| GET | `/api/sistema/rede` | IPs da máquina para o QR Code |
| GET | `/api/sistema/saude` | servidor, banco e IA |
| POST | `/api/leads` | formulário de contato do site |
| DELETE | `/api/controle-acesso/residentes/:id` | remover morador |

`POST /api/controle-acesso/autenticar` agora aceita `registrar: false`
(só compara o rosto, sem gravar no histórico a cada segundo).

## Observação acadêmica

As chamadas para 190/193 são simuladas. O reconhecimento facial roda no
navegador (face-api.js) e os dados de rosto ficam só no seu MySQL.

## Visual (Figma)

O front-end segue o arquivo do Figma "cthulhu": azul-noite, ciano `#22D3EE`
como único acento e a fonte 42dot Sans. Os tokens ficam em
`frontend/base.css`.

- **Central**: perímetro (planta com zoom e sensores) e monitoramento
  (câmeras + atividade recente) lado a lado; assistente embaixo; acesso e
  localização no fim. Clicar numa câmera abre a visualização ampliada com
  "Memorizar rosto", "Ativar IA" e "Simular procurado".
- **Emergência**: botão no topo para 190, 193 ou simular procurado.
