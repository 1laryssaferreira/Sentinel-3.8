import { Router, Request, Response } from 'express';
import { pool } from '../db';
import type { RowDataPacket } from 'mysql2';
import { emitirParaPaineis } from '../tempoReal';

const router = Router();

interface ResidenteRow extends RowDataPacket {
  id: number;
  nome: string;
  documento_id: string | null;
  ativo: number;
  criado_em: string;
}

interface TentativaRow extends RowDataPacket {
  id: number;
  residente_id: number | null;
  residente_nome: string | null;
  resultado: 'AUTORIZADO' | 'NEGADO' | 'PROCURADO';
  origem: string;
  criado_em: string;
}

// GET /api/controle-acesso/residentes — lista de moradores cadastrados no Control ID
router.get('/residentes', async (_req: Request, res: Response) => {
  try {
    const [linhas] = await pool.query<ResidenteRow[]>(
      'SELECT id, nome, documento_id, ativo, criado_em FROM residentes_autorizados ORDER BY id DESC'
    );
    res.json(linhas);
  } catch (erro) {
    console.error('Erro ao listar residentes:', erro);
    res.status(500).json({ erro: 'Não foi possível consultar os residentes cadastrados.' });
  }
});

// POST /api/controle-acesso/residentes — cadastra um morador com sua biometria facial
router.post('/residentes', async (req: Request, res: Response) => {
  const { nome, documentoId, descritorFacial } = req.body;

  if (!nome || nome.trim().length < 2) {
    return res.status(400).json({ erro: 'Informe o nome do residente.' });
  }

  try {
    const [resultado]: any = await pool.query(
      'INSERT INTO residentes_autorizados (nome, documento_id, descritor_facial) VALUES (?, ?, ?)',
      [nome.trim(), documentoId || null, descritorFacial ? JSON.stringify(descritorFacial) : null]
    );
    emitirParaPaineis('residente:novo', { id: resultado.insertId, nome: nome.trim() });
    res.status(201).json({ id: resultado.insertId, nome: nome.trim(), documentoId: documentoId || null });
  } catch (erro) {
    console.error('Erro ao cadastrar residente:', erro);
    res.status(500).json({ erro: 'Não foi possível cadastrar o residente no MySQL.' });
  }
});

// DELETE /api/controle-acesso/residentes/:id — remove um morador (e sua biometria)
router.delete('/residentes/:id', async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ erro: 'ID inválido.' });
  try {
    await pool.query('DELETE FROM residentes_autorizados WHERE id = ?', [id]);
    res.status(204).end();
  } catch (erro) {
    console.error('Erro ao remover residente:', erro);
    res.status(500).json({ erro: 'Não foi possível remover o residente.' });
  }
});

// GET /api/controle-acesso/tentativas?limite=20 — histórico de reconhecimento facial
router.get('/tentativas', async (req: Request, res: Response) => {
  const limite = Math.min(Number(req.query.limite) || 20, 100);

  try {
    const [linhas] = await pool.query<TentativaRow[]>(
      `SELECT t.id, t.residente_id, r.nome AS residente_nome, t.resultado, t.origem, t.criado_em
       FROM tentativas_acesso t
       LEFT JOIN residentes_autorizados r ON r.id = t.residente_id
       ORDER BY t.id DESC LIMIT ?`,
      [limite]
    );
    res.json(linhas);
  } catch (erro) {
    console.error('Erro ao listar tentativas de acesso:', erro);
    res.status(500).json({ erro: 'Não foi possível consultar o histórico de acessos.' });
  }
});

// Distância euclidiana entre dois vetores faciais (128 pontos gerados pelo
// face-api.js). Quanto menor a distância, mais parecidos são os rostos.
function calcularDistanciaEuclidiana(vetorA: number[], vetorB: number[]): number {
  let soma = 0;
  const tamanho = Math.min(vetorA.length, vetorB.length);
  for (let i = 0; i < tamanho; i++) {
    const diferenca = (vetorA[i] ?? 0) - (vetorB[i] ?? 0);
    soma += diferenca * diferenca;
  }
  return Math.sqrt(soma);
}

// Abaixo desse valor, consideramos que é a mesma pessoa. 0.5 é o padrão
// recomendado pela própria face-api.js para o modelo de reconhecimento.
const LIMITE_TOLERANCIA_FACIAL = 0.5;

interface ResidenteComDescritorRow extends RowDataPacket {
  id: number;
  nome: string;
  descritor_facial: string | null;
}

// POST /api/controle-acesso/autenticar — compara um rosto lido pela câmera
// (em qualquer dispositivo: webcam do PC ou câmera do celular) contra TODOS
// os residentes cadastrados no MySQL, e já registra a tentativa de acesso.
// Isso é o que faz o reconhecimento facial funcionar de verdade entre
// sessões/dispositivos — antes, a comparação só existia na memória do
// navegador que tinha feito o cadastro.
router.post('/autenticar', async (req: Request, res: Response) => {
  // registrar=false: só compara, sem gravar no histórico. O painel usa
  // isso a cada leitura (2-3 s) e só registra quando a pessoa muda ou a
  // cada 30 s — senão o banco ganharia uma linha por segundo.
  const { descritorFacial, origem, registrar = true } = req.body;

  if (!Array.isArray(descritorFacial) || descritorFacial.length !== 128) {
    return res.status(400).json({ erro: 'descritorFacial precisa ser um vetor com 128 posições.' });
  }

  try {
    const [residentes] = await pool.query<ResidenteComDescritorRow[]>(
      'SELECT id, nome, descritor_facial FROM residentes_autorizados WHERE ativo = 1 AND descritor_facial IS NOT NULL'
    );

    let melhor: { id: number; nome: string; distancia: number } | null = null;

    for (const residente of residentes) {
      const vetorSalvo: number[] = typeof residente.descritor_facial === 'string'
        ? JSON.parse(residente.descritor_facial)
        : (residente.descritor_facial as unknown as number[]);

      const distancia = calcularDistanciaEuclidiana(descritorFacial, vetorSalvo);
      if (!melhor || distancia < melhor.distancia) {
        melhor = { id: residente.id, nome: residente.nome, distancia };
      }
    }

    const autorizado = melhor !== null && melhor.distancia < LIMITE_TOLERANCIA_FACIAL;

    // Já registra a tentativa aqui mesmo, pra qualquer câmera (PC ou
    // celular) ficar salva no mesmo histórico, sem depender do front-end
    // fazer uma segunda chamada.
    if (registrar !== false) {
      await pool.query(
        'INSERT INTO tentativas_acesso (residente_id, resultado, origem) VALUES (?, ?, ?)',
        [autorizado ? melhor!.id : null, autorizado ? 'AUTORIZADO' : 'NEGADO', origem || 'Reconhecimento Facial']
      );
      emitirParaPaineis('acesso:novo', {
        resultado: autorizado ? 'AUTORIZADO' : 'NEGADO',
        nome: autorizado ? melhor!.nome : null,
        origem: origem || 'Reconhecimento Facial'
      });
    }

    if (autorizado) {
      return res.json({
        status: 'AUTORIZADO',
        residenteId: melhor!.id,
        nome: melhor!.nome,
        distancia: Number(melhor!.distancia.toFixed(3))
      });
    }

    return res.status(200).json({
      status: 'NEGADO',
      nome: null,
      distancia: melhor ? Number(melhor.distancia.toFixed(3)) : null
    });
  } catch (erro) {
    console.error('Erro ao autenticar rosto:', erro);
    res.status(500).json({ erro: 'Não foi possível comparar o rosto com o banco de dados.' });
  }
});

// POST /api/controle-acesso/tentativas — registra o resultado de uma checagem da IA facial
router.post('/tentativas', async (req: Request, res: Response) => {
  const { residenteId, resultado, origem } = req.body;
  const resultadosValidos = ['AUTORIZADO', 'NEGADO', 'PROCURADO'];

  if (!resultadosValidos.includes(resultado)) {
    return res.status(400).json({ erro: `Resultado inválido. Use um de: ${resultadosValidos.join(', ')}` });
  }

  try {
    const [inserido]: any = await pool.query(
      'INSERT INTO tentativas_acesso (residente_id, resultado, origem) VALUES (?, ?, ?)',
      [residenteId || null, resultado, origem || 'Reconhecimento Facial']
    );
    emitirParaPaineis('acesso:novo', { resultado, residenteId: residenteId || null, origem: origem || 'Reconhecimento Facial' });
    res.status(201).json({ id: inserido.insertId, resultado });
  } catch (erro) {
    console.error('Erro ao registrar tentativa de acesso:', erro);
    res.status(500).json({ erro: 'Não foi possível registrar a tentativa de acesso no MySQL.' });
  }
});

export default router;
