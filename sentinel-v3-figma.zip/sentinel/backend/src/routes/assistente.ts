import { Router, Response } from 'express';
import { conversar, configuracaoIA, MensagemChat } from '../ia';
import { exigirAutenticacao, RequisicaoAutenticada } from '../middleware/authMiddleware';

const router = Router();

// Limite simples por operador: evita gastar crédito de API à toa
// (ex.: alguém segurando o Enter). 20 mensagens por minuto.
const JANELA_MS = 60_000;
const MAX_POR_JANELA = 20;
const uso = new Map<number, number[]>();

function dentroDoLimite(usuarioId: number): boolean {
  const agora = Date.now();
  const recentes = (uso.get(usuarioId) || []).filter(t => agora - t < JANELA_MS);
  if (recentes.length >= MAX_POR_JANELA) return false;
  recentes.push(agora);
  uso.set(usuarioId, recentes);
  return true;
}

// GET /api/assistente/status — o painel usa pra mostrar "IA conectada" ou "modo local"
router.get('/status', (_req, res) => {
  const { provedor, modelo } = configuracaoIA();
  res.json({ ativo: provedor !== 'off', provedor, modelo });
});

// POST /api/assistente/chat  { mensagens: [{papel, texto}], estado: {...} }
router.post('/chat', exigirAutenticacao, async (req: RequisicaoAutenticada, res: Response) => {
  const { mensagens, estado } = req.body || {};

  if (!Array.isArray(mensagens) || !mensagens.length) {
    return res.status(400).json({ erro: 'Envie o histórico em "mensagens".' });
  }
  const historico: MensagemChat[] = mensagens
    .filter((m: any) => (m?.papel === 'usuario' || m?.papel === 'assistente') && typeof m?.texto === 'string')
    .map((m: any) => ({ papel: m.papel, texto: String(m.texto).slice(0, 2000) }));

  if (!dentroDoLimite(req.usuario!.id)) {
    return res.status(429).json({ erro: 'Muitas mensagens em pouco tempo. Aguarde alguns segundos.' });
  }

  try {
    const resultado = await conversar(historico, estado ?? {}, req.usuario!.nome);
    res.json(resultado);
  } catch (erro: any) {
    if (erro?.message === 'IA_DESLIGADA') {
      return res.status(503).json({ erro: 'Nenhuma IA configurada no servidor.', fallback: true });
    }
    console.error('Erro no assistente de IA:', erro);
    res.status(502).json({ erro: 'A IA não respondeu. Usando o modo local.', fallback: true });
  }
});

export default router;
